(function() {

    var app = angular.module("empInfo",[]);

    var empController = function($scope) {
      
        var arrEmp = [
                  {name:"Anuj Kumar", dob:"23/11/1982",gender:"male",salary:6789.90,salaryCurrency:"Rs. 6,789.90"},
                  {name:"Amit Kumar", dob:"17/09/1978",gender:"male",salary:678990.90,salaryCurrency:"Rs. 6,78,990.90"},
                  {name:"Sumit Kumar", dob:"15/06/1978",gender:"male",salary:67089.90,salaryCurrency:"Rs. 67,089.90"},
                  {name:"Shwati", dob:"11/01/1992",gender:"female",salary:65757.90,salaryCurrency:"Rs. 65,757.90"},
        ];
      
       $scope.sortProperty = function(prop)
       {
          if($scope.sortColumn === prop)
             $scope.sortColumn  = "-" + prop;
          else
             $scope.sortColumn = prop

       }
       
       $scope.maskSalary = function(salary) {             
             return salary.toString().replace(/./g, '#');
        };
     

       $scope.empList = arrEmp;
       $scope.sortColumn = "name";
       //$scope.isMaskSalary = false;
    };

    app.controller("empController",empController);

}());